var express = require('express');
var router = express.Router();
var util = require('./mBehutil.js');
var alertHtml = require('./alert.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.all('/get', function(req, res, next) {
	if(util.getReqStrByKey(req,'name')=='alert'){
		res.send(alertHtml.alertHtml);
	}else{
		res.render('error',{error:{stack:'NOT FOUND !'}})
	}
});

module.exports = router;
